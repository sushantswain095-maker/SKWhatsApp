# SK WhatsApp - Gold & Black Liquid Glass (visual prototype)

Independent Android UI prototype (Kotlin + Jetpack Compose). Not affiliated with WhatsApp.

## Build
1. Install Android Studio (Ladybug or newer) and open this folder.
2. Let Gradle sync (it downloads the SDK pieces and creates the wrapper).
3. Pick a device or emulator (try Pixel 4, Pixel 8, a foldable and a tablet) and press Run.
   For an APK: Build > Build APK(s). Output: app/build/outputs/apk/debug/app-debug.apk

## Status
Working UI: 5 tabs, chat list search, chat screen with sending, attachment menu, toggles.
Not implemented: real messaging, accounts, voice notes, calls, status, persistence.
The only WhatsApp link is Settings > Open WhatsApp (standard wa.me link).
Glass is simulated with translucent gradients and gold edge light, not true backdrop blur.

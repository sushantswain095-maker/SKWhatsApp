package com.sk.goldblack

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Msg(val text: String, val mine: Boolean, val time: String)
data class Chat(val name: String, val last: String, val time: String, val unread: Int, val thread: List<Msg>)

// Demo data only. Nothing here is a real conversation.
val demoChats = listOf(
    Chat("Studio Team", "Final gold palette is approved", "9:41", 2, listOf(
        Msg("Morning! Did you see the new glass nav?", false, "9:38"),
        Msg("Yes, the gold edge light looks great.", true, "9:39"),
        Msg("Final gold palette is approved", false, "9:41"))),
    Chat("Ria Sharma", "Dinner at 8?", "8:15", 0, listOf(
        Msg("Dinner at 8?", false, "8:15"), Msg("Booked. See you there.", true, "8:16"))),
    Chat("Kabir", "Sent the files", "Yesterday", 0, listOf(
        Msg("Sent the files", false, "6:02 pm"), Msg("Got them, thanks!", true, "6:05 pm"))),
    Chat("Weekend Plans", "Who is driving?", "Yesterday", 5, listOf(
        Msg("Who is driving?", false, "4:30 pm"))),
    Chat("Gold Club", "Welcome to the club", "Mon", 0, listOf(
        Msg("Welcome to the club", false, "10:00")))
)

fun demoToast(ctx: Context) =
    Toast.makeText(ctx, "Prototype only: not connected yet", Toast.LENGTH_SHORT).show()

@Composable
fun ScreenList(title: String, content: LazyListScope.() -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Text(
            title,
            style = TextStyle(brush = SK.GoldBrush, fontSize = 34.sp, fontWeight = FontWeight.Bold),
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)
        )
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            content = content
        )
    }
}

@Composable
fun SearchPill(value: String, onChange: (String) -> Unit) {
    Row(
        Modifier.fillMaxWidth().glass(RoundedCornerShape(22.dp)).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Search, null, tint = SK.Muted)
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f)) {
            if (value.isEmpty()) Text("Search", color = SK.Muted)
            BasicTextField(
                value, onChange, singleLine = true,
                textStyle = TextStyle(color = SK.Ink, fontSize = 16.sp),
                cursorBrush = SolidColor(SK.Gold), modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun ChatsScreen(onOpen: (Chat) -> Unit) {
    var q by remember { mutableStateOf("") }
    val shown = demoChats.filter { it.name.contains(q, ignoreCase = true) }
    ScreenList("Chats") {
        item { SearchPill(q) { q = it } }
        items(shown) { c -> ChatRow(c) { onOpen(c) } }
    }
}

@Composable
fun ChatRow(c: Chat, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().glass(RoundedCornerShape(24.dp), 0.05f).clickable(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(c.name)
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(c.name, color = SK.Ink, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
            Text(c.last, color = SK.Muted, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(c.time, color = if (c.unread > 0) SK.Gold else SK.Muted, fontSize = 12.sp)
            if (c.unread > 0) Box(
                Modifier.padding(top = 6.dp).size(22.dp).background(SK.GoldBrush, CircleShape),
                contentAlignment = Alignment.Center
            ) { Text("${c.unread}", color = SK.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
fun UpdatesScreen() {
    val ctx = LocalContext.current
    ScreenList("Updates") {
        item {
            GlassRow("My status", "Tap + to add an update",
                leading = { ProfileAvatar(52.dp) },
                trailing = { GoldButton(Icons.Rounded.Add, 40.dp) { demoToast(ctx) } })
        }
        item { SectionLabel("Recent updates") }
        items(demoChats.take(4)) { c -> GlassRow(c.name, "Posted ${c.time}", leading = { Avatar(c.name, ring = true) }) }
    }
}

@Composable
fun CommunitiesScreen() {
    ScreenList("Communities") {
        item { GlassRow("New community", "Bring your groups together", leading = { GoldIconBadge(Icons.Rounded.Groups) }) }
        items(listOf("Gold Club" to 4, "Studio Team" to 3)) { (n, g) ->
            GlassRow(n, "$g groups", leading = { Avatar(n) })
        }
    }
}

@Composable
fun CallsScreen() {
    val ctx = LocalContext.current
    val calls = listOf(Triple("Ria Sharma", "Missed", false), Triple("Kabir", "Outgoing", true), Triple("Studio Team", "Incoming", false))
    ScreenList("Calls") {
        items(calls) { (n, kind, video) ->
            GlassRow(n, kind, leading = { Avatar(n) }, trailing = {
                IconButton(onClick = { demoToast(ctx) }) {
                    Icon(if (video) Icons.Rounded.Videocam else Icons.Rounded.Call, null, tint = SK.Gold)
                }
            })
        }
    }
}

@Composable
fun ToggleRow(title: String, on: Boolean, onChange: (Boolean) -> Unit) {
    GlassRow(title, trailing = {
        Switch(
            on, onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = SK.Black, checkedTrackColor = SK.Gold, checkedBorderColor = SK.GoldLight,
                uncheckedThumbColor = SK.Muted, uncheckedTrackColor = Color(0x22FFFFFF), uncheckedBorderColor = Color(0x33FFFFFF)
            )
        )
    })
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    var notif by remember { mutableStateOf(true) }
    var preview by remember { mutableStateOf(true) }
    var sound by remember { mutableStateOf(true) }
    ScreenList("Settings") {
        item {
            Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(28.dp)).padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                ProfileAvatar(68.dp)
                Column(Modifier.padding(start = 16.dp)) {
                    Text("SK Member", color = SK.Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Prototype profile", color = SK.Muted, fontSize = 13.sp)
                }
            }
        }
        item { SectionLabel("Notifications (not saved yet)") }
        item { ToggleRow("Message notifications", notif) { notif = it } }
        item { ToggleRow("Show previews", preview) { preview = it } }
        item { ToggleRow("Sounds", sound) { sound = it } }
        item { SectionLabel("Appearance") }
        item { GlassRow("Theme", "Gold and Black, dark", leading = { GoldIconBadge(Icons.Rounded.Palette) }) }
        item { SectionLabel("Official WhatsApp") }
        item {
            GlassRow("Open WhatsApp", "Uses the standard wa.me link",
                onClick = { runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/"))) } },
                leading = { GoldIconBadge(Icons.Rounded.Link) })
        }
        item {
            Text(
                "Visual prototype. It does not send or receive messages and is not affiliated with WhatsApp.",
                color = SK.Muted, fontSize = 12.sp, modifier = Modifier.padding(8.dp)
            )
        }
    }
}

@Composable
fun Bubble(m: Msg) {
    val state = remember { MutableTransitionState(false).apply { targetState = true } }
    val shape = RoundedCornerShape(20.dp, 20.dp, if (m.mine) 6.dp else 20.dp, if (m.mine) 20.dp else 6.dp)
    AnimatedVisibility(
        visibleState = state,
        enter = fadeIn() + scaleIn(initialScale = 0.85f, transformOrigin = TransformOrigin(if (m.mine) 1f else 0f, 1f)) +
            slideInVertically { it / 3 }
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.mine) Arrangement.End else Arrangement.Start) {
            Column(
                Modifier.widthIn(max = 290.dp)
                    .then(if (m.mine) Modifier.clip(shape).background(SK.GoldBrush) else Modifier.glass(shape, 0.06f))
                    .padding(horizontal = 14.dp, vertical = 9.dp),
                horizontalAlignment = Alignment.End
            ) {
                Text(m.text, color = if (m.mine) SK.Black else SK.Ink, fontSize = 16.sp)
                Text(m.time, color = if (m.mine) SK.Black.copy(alpha = 0.6f) else SK.Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun AttachItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onClick)) {
        GoldIconBadge(icon, 52.dp)
        Text(label, color = SK.Ink, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
fun ChatScreen(chat: Chat, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val msgs = remember { mutableStateListOf<Msg>().apply { addAll(chat.thread) } }
    var text by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    val list = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) list.animateScrollToItem(msgs.lastIndex) }

    Box(Modifier.fillMaxSize().imePadding()) {
        LazyColumn(
            state = list, modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 130.dp, bottom = 110.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) { items(msgs) { Bubble(it) } }

        Row(
            Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(12.dp)
                .glass(RoundedCornerShape(30.dp)).padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back", tint = SK.GoldLight) }
            Avatar(chat.name, 40.dp)
            Column(Modifier.weight(1f).padding(start = 10.dp)) {
                Text(chat.name, color = SK.Ink, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1)
                Text("Prototype chat", color = SK.Muted, fontSize = 12.sp)
            }
            IconButton(onClick = { demoToast(ctx) }) { Icon(Icons.Rounded.Videocam, "Video", tint = SK.Gold) }
            IconButton(onClick = { demoToast(ctx) }) { Icon(Icons.Rounded.Call, "Call", tint = SK.Gold) }
        }

        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(12.dp)) {
            AnimatedVisibility(
                menu,
                enter = fadeIn() + scaleIn(initialScale = 0.85f, transformOrigin = TransformOrigin(0f, 1f)) + slideInVertically { it / 2 },
                exit = fadeOut() + scaleOut(targetScale = 0.85f, transformOrigin = TransformOrigin(0f, 1f))
            ) {
                Row(
                    Modifier.padding(bottom = 10.dp).fillMaxWidth().glass(RoundedCornerShape(28.dp)).padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    val tap = { menu = false; demoToast(ctx) }
                    AttachItem(Icons.Rounded.Image, "Photos", tap)
                    AttachItem(Icons.Rounded.PhotoCamera, "Camera", tap)
                    AttachItem(Icons.Rounded.Description, "Document", tap)
                    AttachItem(Icons.Rounded.LocationOn, "Location", tap)
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                GlassButton(Icons.Rounded.Add) { menu = !menu }
                Spacer(Modifier.width(8.dp))
                Box(Modifier.weight(1f).glass(RoundedCornerShape(26.dp)).padding(horizontal = 16.dp, vertical = 12.dp)) {
                    if (text.isEmpty()) Text("Message", color = SK.Muted, fontSize = 16.sp)
                    BasicTextField(
                        text, { text = it }, maxLines = 4,
                        textStyle = TextStyle(color = SK.Ink, fontSize = 16.sp),
                        cursorBrush = SolidColor(SK.Gold), modifier = Modifier.fillMaxWidth()
                    )
                }
                Spacer(Modifier.width(8.dp))
                GoldButton(if (text.isBlank()) Icons.Rounded.Mic else Icons.AutoMirrored.Rounded.Send) {
                    if (text.isBlank()) demoToast(ctx) else { msgs.add(Msg(text.trim(), true, "now")); text = "" }
                }
            }
        }
    }
}

package com.sk.goldblack

import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object SK {
    val Black = Color(0xFF050507)
    val Gold = Color(0xFFD4AF37)
    val GoldLight = Color(0xFFF6E7A6)
    val GoldDeep = Color(0xFF8C6A14)
    val Ink = Color(0xFFF4EFE2)
    val Muted = Color(0xFF9A957F)
    val GoldBrush: Brush get() = Brush.linearGradient(listOf(GoldLight, Gold, GoldDeep))
}

@Composable
fun SKTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = SK.Gold, onPrimary = SK.Black,
            background = SK.Black, surface = SK.Black,
            onBackground = SK.Ink, onSurface = SK.Ink
        ),
        content = content
    )
}

/** Frosted-glass look: translucent fill + gold edge light + soft gold shadow.
 *  This is a simulated glass (no real backdrop blur) so it works on every Android version. */
fun Modifier.glass(shape: Shape = RoundedCornerShape(24.dp), strength: Float = 0.08f): Modifier = this
    .shadow(16.dp, shape, ambientColor = Color.Black, spotColor = SK.Gold.copy(alpha = 0.35f))
    .clip(shape)
    .background(
        Brush.verticalGradient(
            listOf(Color.White.copy(alpha = strength + 0.07f), Color.White.copy(alpha = strength * 0.5f))
        )
    )
    .border(
        1.dp,
        Brush.linearGradient(
            listOf(SK.GoldLight.copy(alpha = 0.7f), SK.Gold.copy(alpha = 0.08f), SK.Gold.copy(alpha = 0.35f))
        ),
        shape
    )

@Composable
fun GlassBackdrop(content: @Composable BoxScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(SK.Black)) {
        Box(
            Modifier.align(Alignment.TopStart).offset(x = (-120).dp, y = (-80).dp).size(420.dp)
                .background(Brush.radialGradient(listOf(SK.Gold.copy(alpha = 0.30f), Color.Transparent)), CircleShape)
        )
        Box(
            Modifier.align(Alignment.BottomEnd).offset(x = 140.dp, y = 120.dp).size(460.dp)
                .background(Brush.radialGradient(listOf(SK.GoldDeep.copy(alpha = 0.35f), Color.Transparent)), CircleShape)
        )
        content()
    }
}

data class TabItem(val label: String, val icon: ImageVector)

@Composable
fun GlassTabBar(tabs: List<TabItem>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier.navigationBarsPadding().padding(horizontal = 18.dp, vertical = 14.dp)
            .glass(RoundedCornerShape(36.dp), 0.07f).padding(6.dp)
    ) {
        tabs.forEachIndexed { i, t ->
            val sel = i == selected
            val bg by animateColorAsState(if (sel) SK.Gold.copy(alpha = 0.22f) else Color.Transparent, label = "tab")
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(30.dp)).background(bg)
                    .clickable { onSelect(i) }.padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(t.icon, t.label, tint = if (sel) SK.GoldLight else SK.Muted, modifier = Modifier.size(24.dp))
                Text(t.label, color = if (sel) SK.GoldLight else SK.Muted, fontSize = 10.sp, maxLines = 1)
            }
        }
    }
}

@Composable
fun GoldButton(icon: ImageVector, size: Dp = 48.dp, onClick: () -> Unit) {
    Box(
        Modifier.size(size).shadow(14.dp, CircleShape, spotColor = SK.Gold).clip(CircleShape)
            .background(SK.GoldBrush).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Crossfade(icon, label = "icon") { Icon(it, null, tint = SK.Black) } }
}

@Composable
fun GlassButton(icon: ImageVector, size: Dp = 48.dp, onClick: () -> Unit) {
    Box(Modifier.size(size).glass(CircleShape, 0.08f).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = SK.GoldLight)
    }
}

@Composable
fun Avatar(name: String, size: Dp = 52.dp, ring: Boolean = false) {
    val initials = name.split(" ").take(2).map { it.first().uppercaseChar() }.joinToString("")
    Box(
        Modifier.size(size).clip(CircleShape)
            .background(Brush.linearGradient(listOf(Color(0xFF2A2A31), Color(0xFF111115))))
            .border(if (ring) 2.dp else 1.dp, SK.GoldBrush, CircleShape),
        contentAlignment = Alignment.Center
    ) { Text(initials, color = SK.GoldLight, fontWeight = FontWeight.SemiBold, fontSize = (size.value * 0.34f).sp) }
}

@Composable
fun ProfileAvatar(size: Dp = 64.dp) {
    Box(Modifier.size(size).clip(CircleShape).background(SK.GoldBrush), contentAlignment = Alignment.Center) {
        Text("SK", color = SK.Black, fontWeight = FontWeight.ExtraBold, fontSize = (size.value * 0.36f).sp)
    }
}

@Composable
fun GoldIconBadge(icon: ImageVector, size: Dp = 48.dp) {
    Box(
        Modifier.size(size).clip(CircleShape).background(Color(0x26D4AF37)).border(1.dp, SK.GoldBrush, CircleShape),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = SK.GoldLight) }
}

@Composable
fun SectionLabel(text: String) {
    Text(text, color = SK.Gold, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 8.dp, top = 10.dp))
}

@Composable
fun GlassRow(
    title: String,
    subtitle: String? = null,
    onClick: (() -> Unit)? = null,
    leading: (@Composable () -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null
) {
    Row(
        Modifier.fillMaxWidth().glass(RoundedCornerShape(24.dp), 0.05f)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (leading != null) { leading(); Spacer(Modifier.width(12.dp)) }
        Column(Modifier.weight(1f)) {
            Text(title, color = SK.Ink, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            if (subtitle != null) Text(subtitle, color = SK.Muted, fontSize = 13.sp)
        }
        if (trailing != null) trailing()
    }
}

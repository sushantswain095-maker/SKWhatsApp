package com.sk.goldblack

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.ChatBubble
import androidx.compose.material.icons.rounded.DonutLarge
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val clear = android.graphics.Color.TRANSPARENT
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(clear),
            navigationBarStyle = SystemBarStyle.dark(clear)
        )
        setContent { SKTheme { SKApp() } }
    }
}

private val tabs = listOf(
    TabItem("Chats", Icons.Rounded.ChatBubble),
    TabItem("Updates", Icons.Rounded.DonutLarge),
    TabItem("Communities", Icons.Rounded.Groups),
    TabItem("Calls", Icons.Rounded.Call),
    TabItem("Settings", Icons.Rounded.Settings)
)

@Composable
fun SKApp() {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var open by remember { mutableStateOf<Chat?>(null) }
    GlassBackdrop {
        AnimatedContent(
            targetState = open,
            transitionSpec = {
                if (targetState != null)
                    (slideInHorizontally { it } + fadeIn()) togetherWith (slideOutHorizontally { -it / 3 } + fadeOut())
                else
                    (slideInHorizontally { -it / 3 } + fadeIn()) togetherWith (slideOutHorizontally { it } + fadeOut())
            },
            label = "nav"
        ) { chat ->
            if (chat != null) {
                BackHandler { open = null }
                ChatScreen(chat) { open = null }
            } else {
                Box(Modifier.fillMaxSize()) {
                    Crossfade(tab, label = "tabs") { t ->
                        when (t) {
                            0 -> ChatsScreen { open = it }
                            1 -> UpdatesScreen()
                            2 -> CommunitiesScreen()
                            3 -> CallsScreen()
                            else -> SettingsScreen()
                        }
                    }
                    GlassTabBar(tabs, tab, { tab = it }, Modifier.align(Alignment.BottomCenter))
                }
            }
        }
    }
}
